<?php
    require('requires/meta_tags.php');
    ?>
<?php
    require('requires/header_styling2.php');
    ?>
        
        html, body {
            height: 100%;
            margin: 0;
            font-family: 'Segoe UI', 'Trajan Pro', Arial, sans-serif;
            background: #080909 url('https://images.unsplash.com/photo-1506744038136-46273834b3fb?auto=format&fit=crop&w=1600&q=80') center center/cover no-repeat fixed;
            color: #fff5df;
            min-height: 100vh;
            width: 100vw;
            overflow-x: hidden;
        }
        body:after {
            content: "";
            position: fixed;
            z-index: 0;
            inset: 0;
            pointer-events: none;
            background: linear-gradient(120deg, #0f131e66 30%, #19120aee 100%),
                        radial-gradient(ellipse at 70% 20%, #25240b33 34%, #27171066 76%, #000 100%);
            mix-blend-mode: multiply;
        }
        body {
            min-height: 100vh;
            display: flex;
            flex-direction: column;
            margin: 0;
            width: 100vw;
        }
        :root {
                    --accent-blue: #253144;
                    --accent-blue2: #191a23;
                    --shadow: 0 6px 32px rgba(54,41,138,0.22);
                    --round: 20px;
                }
        main {
            flex: 1 1 0;
            display: flex;
            flex-direction: column;
            align-items: stretch;
            justify-content: center;
            min-height: 0;
            min-width: 0;
            height: 100%;
            width: 100vw;
            margin: 0;
            padding: 0.5rem 2vw 1.1rem 2vw;
            background: rgba(24,17,10,0.84);
            border-radius: var(--round);
            box-shadow: 0 16px 60px 0 #0e0c07c0, 0 2px 4px #dab56245;
            position: relative;
            max-width: 1700px;
            margin-left: auto;
            margin-right: auto;
            z-index: 2;
        }
        main:after {
            content:'';
            pointer-events: none;
            z-index: 3;
            position: absolute;
            inset:0;
            mix-blend-mode: lighten;
            background:
                radial-gradient(ellipse 75% 40% at 55% 98%, #d3a13b0b 0%, #dab56215 80%, transparent 100%),
                radial-gradient(ellipse 120% 50% at 35% 110%, #f7ee9a10 23%, transparent 100%),
                url('https://www.transparenttextures.com/patterns/soft-wallpaper.png');
            opacity: 0.44;
        }
        .dropdown-bar {
            flex: 0 0 auto;
            width: 100%;
            background: rgba(23,24,11,0.93);
            border-radius: 15px;
            box-shadow: 0 1px 12px #5036001c;
            border: 1.5px solid #70562255;
            padding: 0.2rem 0.6rem;
            display: flex;
            gap: 1.1rem;
            justify-content: center;
            align-items: center;
            margin-bottom: 0.5rem;
            min-height: 61px;
        }
        /* Restored Original Dropdown Button Style */
        .dropdown {
            position: relative;
        }
        .dropbtn {
            background: linear-gradient(90deg, #dab562 0%, #a3822d 100%);
            color: #242113;
            padding: 0.48rem 1.15rem;
            border: none;
            border-radius: 11px;
            cursor: pointer;
            font-size: 1.02rem;
            font-weight: 600;
            letter-spacing: 1px;
            transition: box-shadow 0.18s, background 0.18s, color 0.14s, transform 0.13s;
            box-shadow: 0 2px 18px #ad8a2d12;
            outline: none;
        }
        .dropbtn:focus, .dropbtn:hover {
            background: linear-gradient(90deg, #a3822d 0%, #dab562 100%);
            box-shadow: 0 4px 24px #dab56299;
            transform: scale(1.045);
            color: #463c12;
        }
        .dropdown-content {
            display: none;
            position: absolute;
            left: 0;
            top: 108%;
            background: #181612ee;
            min-width: 192px;
            box-shadow: 0 12px 44px #dab56241;
            border-radius: 12px;
            z-index: 20;
            padding: 0.38em 0.22em;
            flex-direction: column;
            animation: dropdownFadeIn 0.32s;
            margin-top: 7px;
            border: 1.5px solid #dab56244;
        }
        @keyframes dropdownFadeIn {
            from { opacity: 0; transform: translateY(-22px);}
            to { opacity: 1; transform: translateY(0);}
        }
        .dropdown.show > .dropdown-content { display: flex; }
        .dropdown-content-column {
            display: flex;
            flex-direction: column;
            gap: 0.12rem;
            margin: 0 0.22em;
        }
        .dropdown-content a {
            color: #dab562 !important;
            padding: 9px 15px;
            text-decoration: none;
            display: block;
            border-radius: 8px;
            background: none;
            border: none;
            text-align: center;
            font-size: 1.03em;
            cursor: pointer;
            transition: background 0.16s, color 0.13s, transform 0.12s;
            white-space: nowrap;
        }
        .dropdown-content a:hover {
            background: #dab562ad;
            color: #3c3313 !important;
            transform: translateX(3px) scale(1.045);
        }
        .dropdown-content-row {
            display: flex;
            flex-direction: row;
            gap: 0.2rem;
        }
        .splitter-title {
            background: #313112e0;
            color: #dab562;
            border-radius: 8px;
            padding: 5px 14px;
            font-size: 1.03rem;
            text-align: center;
            font-weight: 600;
            letter-spacing: 0.7px;
            margin-bottom: 0.18em;
            margin-top: 0.07em;
            min-width: 90px;
            box-shadow: 0 1.8px 11px #dab56217;
            border: 1.2px solid #dab56233;
        }
        .dropdown-nested {
            display: flex;
            flex-direction: column;
            align-items: center;
            min-width: 110px;
        }
        .dropdown-nested .dropdown-content {
            position: static;
            background: transparent;
            box-shadow: none;
            border-radius: 0;
            border: 0;
            padding: 0;
            animation: none;
            display: flex;
            flex-direction: column;
        }
        .dropdown-nested > .dropdown-content > .dropdown-content-column {
            font-size: 0.99em;
            min-width: 100px;
        }
        .main-flex-fill {
            display: flex;
            flex: 1 1 auto;
            align-items: stretch;
            justify-content: center;
            width: 100%;
        }
        .loader-wrapper {
            flex: 1 1 auto;
            display: flex;
            align-items: stretch;
            justify-content: center;
            background: linear-gradient(120deg, #271c08ee 45%, #272124e6 100%);
            border-radius: 20px;
            box-shadow: 0 8px 54px #0e0c0771, 0 2px 5px #dab56213;
            border: 1.3px solid #dab56255;
            min-height: 350px;
            min-width: 0;
            width: 100%;
            height: 100%;
            position: relative;
            overflow: hidden;
        }
        #gearset-iframe {
            opacity: 0;
            transition: opacity 0.65s cubic-bezier(.4,0,.2,1);
            width: 100%;
            height: 100%;
            border: none;
            position: absolute;
            left: 0; top: 0;
            background: transparent;
            z-index: 2;
            border-radius: 18px;
            min-height: 350px;
            min-width: 0;
        }
        #gearset-iframe.visible { opacity: 1; z-index: 3; }
        .spinner {
            border: 6px solid #dab56230;
            border-top: 6px solid var(--accent-gold);
            border-radius: 50%;
            width: 52px;
            height: 52px;
            animation: spin 1.3s linear infinite;
            margin: auto;
            position: relative;
            z-index: 4;
            background: none;
        }
        @keyframes spin { 100% {transform: rotate(360deg);} }
        footer {
            background: linear-gradient(92deg, #191813ff 0%, #373012f9 100%);
            border-radius: var(--round) var(--round) 0 0;
            margin-top: 2.5rem;
            text-align: center;
            padding: 1.03rem 0;
            font-size: 1.02rem;
            opacity: 0.93;
            color: #dab562;
            letter-spacing: 0.8px;
            box-shadow: 0 -2px 16px #0004;
            border-top: 1.5px solid #dab56246;
        }
        footer a {
            color: #fff5df;
        }
        @media (min-width: 1700px) {
            main, .loader-wrapper, .dropdown-bar {
                max-width: 1700px;
            }
        }
        @media (max-width: 1450px) {
            main, .loader-wrapper, .dropdown-bar {
                max-width: 99vw;
            }
        }
        @media (max-width: 1100px) {
            main {
                padding: 1.2rem 0.7rem 1.2rem 0.7rem;
            }
            .loader-wrapper {
                min-height: 290px;
            }
            .dropdown-bar { gap: 0.7rem; }
        }
        @media (max-width: 900px) {
            .dropdown-bar { flex-wrap: wrap; justify-content: flex-start; }
        }
        
        
        /* ----------- SCROLLABLE ADMIN PATCH ----------- */
        body.admin-panel-mode, html.admin-panel-mode {
            height: auto !important;
            min-height: 100vh !important;
            max-height: none !important;
            overflow-y: auto !important;
            display: block !important;
        }
        body.admin-panel-mode main,
        body.admin-panel-mode #admin-menu {
            max-height: none !important;
            overflow: visible !important;
        }
        body.admin-panel-mode header, body.admin-panel-mode main {
            width: 100% !important;
        }
        body.admin-panel-mode main {
            /* Make admin area wide and centered up to 1200px */
            max-width: 1900px !important;
            width: 95vw !important;
            min-width: 300px;
            margin: 0.2rem auto 2rem auto !important;
            padding: 0.8rem 2.3rem !important;
            box-sizing: border-box;
        }
        body.admin-panel-mode #admin-menu > div {
            /* Each dropdown panel fills almost the full width */
            max-width: 1850px;
            width: 100%;
            margin-left: auto;
            margin-right: auto;
        }
        @media (max-width: 1300px) {
            body.admin-panel-mode main {
                max-width: 99vw !important;
                padding-left: 0.4rem !important;
                padding-right: 0.4rem !important;
            }
            body.admin-panel-mode #admin-menu > div {
                max-width: 99vw;
            }
        }

        /* ---------------------------------------------- */
        
.build-schema {
  background: #191813ee;
  padding: 1em;
  border-radius: 24px;
  margin-top: 1em;
  box-shadow: 0 2px 16px #dab56250;
  color: #dab562;
}
.build-schema .row, .build-schema .gear-row {
  display: flex;
  gap: 1em;
  margin-bottom: 10px;
}
.build-schema .gear-row > div {
  flex: 1 1 0;
  border: 1px solid #dab56266;
  border-radius: 7px;
  padding: 0.5em;
  text-align: center;
  background: #232016eb;
}
.build-schema .attribute-trees, .build-schema .perks {
  margin-top: 1em;
  border-top: 1.5px solid #dab56244;
  padding-top: 1em;
}

    </style>
</head>
<body>
    <?php
    require('requires/header.php');
    ?>
    <main>
        <section class="dropdown-bar" id="dropdowns"></section>
        <div id="build-info"></div>
                   
    </main>
    <footer>
        &copy; 2025 LLangi. All rights reserved. Appreciations to <a href="https://www.nw-buddy.de/" style="text-decoration: underline">nw-buddy</a>.
        
    </footer>
    <script>
 <?php
    require('requires/header_script.php');
    ?>

       
        
        
    let dropdownConfig = [];
    let isAdmin = false;
    function renderLinks(links, isNested = false) {
        if (!links) return '';
        const nestedDropdowns = links.filter(link => link.children !== undefined);
        const simpleLinks = links.filter(link => link.children === undefined);
        let html = '';
        if (simpleLinks.length) {
            html += simpleLinks.map(link =>
                `<a href="#" class="gearset-link build-link" onclick="loadNwBuddyBuildDetails('${link.url}')" data-gearset-url="${link.url || ''}">${link.text}</a>`
            ).join('');
        }
        if (nestedDropdowns.length) {
            html += `<div class="dropdown-content-row">`;
            html += nestedDropdowns.map(link => `
                <div class="dropdown-nested">
                    <div class="splitter-title">${link.text}</div>
                    <div class="dropdown-content">
                        <div class="dropdown-content-column">
                            ${renderLinks(link.children, true)}
                        </div>
                    </div>
                </div>
            `).join('');
            html += `</div>`;
        }
        return html;
    }
    function renderDropdowns(config) {
        const container = document.getElementById('dropdowns');
        container.innerHTML = '';
        config.forEach((dropdown, idx) => {
            let column = document.createElement('div');
            column.className = 'dropdown';
            column.innerHTML = `
                <button class="dropbtn" tabindex="0">${dropdown.title}</button>
                <div class="dropdown-content">
                    <div class="dropdown-content-column">
                        ${renderLinks(dropdown.links)}
                    </div>
                </div>
            `;
            container.appendChild(column);
        });
        attachDropdownAndLoaderLogic();
    }
    function attachDropdownAndLoaderLogic() {
        document.querySelectorAll('.dropbtn').forEach(function(btn) {
            btn.addEventListener('click', function(e) {
                e.preventDefault();
                document.querySelectorAll('.dropdown').forEach(function(drop) {
                    if (drop !== btn.parentElement) drop.classList.remove('show');
                });
                btn.parentElement.classList.toggle('show');
            });
        });
        document.addEventListener('click', function(e) {
            if (!e.target.closest('.dropdown')) {
                document.querySelectorAll('.dropdown').forEach(function(drop) { drop.classList.remove('show'); });
            }
        });
        const links = document.querySelectorAll('.gearset-link');
        const iframe = document.getElementById('gearset-iframe');
        const spinner = document.getElementById('loader-spinner');
        links.forEach(link => {
            link.addEventListener('click', function(e) {
                e.preventDefault();
                const url = this.getAttribute('data-gearset-url');
                if (url && iframe) {
                    spinner.style.display = "block";
                    iframe.classList.remove('visible');
                    iframe.src = "";
                    setTimeout(() => { iframe.src = url; }, 60);
                    iframe.onload = function() {
                        iframe.classList.add('visible');
                        spinner.style.display = "none";
                        iframe.scrollIntoView({behavior: "smooth"});
                    };
                    setTimeout(() => { spinner.style.display = "none"; }, 8000); // Fallback
                }
                document.querySelectorAll('.dropdown').forEach(function(drop) { drop.classList.remove('show'); });
            });
        });
    }
    function loadConfig() {
        fetch('dropdown_config.php')
            .then(r => r.json())
            .then(cfg => {
                dropdownConfig = cfg.isAdmin ? cfg.config : cfg;
                if (isAdmin) renderAdminMenu();
                else renderDropdowns(cfg.config || cfg);
            });
    }
    function renderAdminLinks(links, parentIdx, path=[]) {
        if (!links) return '';
        let html = '';
        links.forEach((link, lidx) => {
            const currentPath = [...path, lidx];
            if (link.children !== undefined) {
                html += `
                    <li style="margin-top:8px;">
                        <span class="splitter-title">${link.text}</span>
                        <button onclick="editDropdown(${parentIdx},[${currentPath}])">Edit</button>
                        <button onclick="moveLink(${parentIdx},[${currentPath}],'up')">Up</button>
                        <button onclick="moveLink(${parentIdx},[${currentPath}],'down')">Down</button>
                        <button onclick="removeLinkAtPath(${parentIdx},[${currentPath}])">Remove</button>
                        <button onclick="addNestedLink(${parentIdx},[${currentPath}])">Add Nested Link</button>
                        <ul>
                            ${renderAdminLinks(link.children, parentIdx, currentPath)}
                        </ul>
                    </li>
                `;
            } else {
                html += `
                    <li>
                        ${link.text} ${link.url ? `- ${link.url}` : ''}
                        <button onclick="editLink(${parentIdx},[${currentPath}])">Edit</button>
                        <button onclick="moveLink(${parentIdx},[${currentPath}],'up')">Up</button>
                        <button onclick="moveLink(${parentIdx},[${currentPath}],'down')">Down</button>
                        <button onclick="removeLinkAtPath(${parentIdx},[${currentPath}])">Remove</button>
                        <button onclick="addNestedDropdown(${parentIdx},[${currentPath}])">Add Splitter Title</button>
                    </li>
                `;
            }
        });
        return html;
    }
    function renderAdminMenu() {
        let html = dropdownConfig.map((dropdown, idx) => `
            <div style="margin-bottom:1rem;padding:1rem;background:#23272a;border-radius:8px;">
                <b>Dropdown ${idx+1}: ${dropdown.title}</b>
                <button onclick="editDropdownTitle(${idx})">Edit</button>
                <button onclick="moveDropdown(${idx},'up')">Up</button>
                <button onclick="moveDropdown(${idx},'down')">Down</button>
                <button onclick="removeDropdown(${idx})">Remove</button>
                <ul>
                    ${renderAdminLinks(dropdown.links, idx)}
                </ul>
                <input id="linkText${idx}" placeholder="Link text">
                <input id="linkUrl${idx}" placeholder="Link URL">
                <button onclick="addLink(${idx})">Add Link</button>
            </div>
        `).join("");
        document.getElementById("admin-menu").innerHTML = html;
    }
    function getLinkByPath(links, path) {
        let node = links;
        for(let i = 0; i < path.length; i++) {
            node = node[path[i]];
            if (i < path.length - 1) node = node.children;
        }
        return node;
    }
    function removeLinkAtPath(dropdownIdx, path) {
        let links = dropdownConfig[dropdownIdx].links;
        let last = path.pop();
        let parent = path.length ? getLinkByPath(links, path).children : links;
        parent.splice(last, 1);
        saveConfig();
    }
    function addNestedDropdown(dropdownIdx, path) {
        let links = dropdownConfig[dropdownIdx].links;
        let link = getLinkByPath(links, path);
        if (!link.children) link.children = [];
        link.url = undefined;
        link.text = prompt("Splitter title:", link.text || "");
        saveConfig();
    }
    function addNestedLink(dropdownIdx, path) {
        let text = prompt("Nested Link text?");
        let url = prompt("Nested Link URL?");
        if (!text || !url) return;
        let links = dropdownConfig[dropdownIdx].links;
        let link = getLinkByPath(links, path);
        if (!link.children) link.children = [];
        link.children.push({text, url});
        saveConfig();
    }
    function addLink(idx) {
        let text = document.getElementById("linkText"+idx).value;
        let url = document.getElementById("linkUrl"+idx).value;
        if (!text || !url) return;
        dropdownConfig[idx].links.push({text, url});
        saveConfig();
    }
    function removeDropdown(idx) {
        dropdownConfig.splice(idx,1);
        saveConfig();
    }
    function editLink(dropdownIdx, path) {
        let links = dropdownConfig[dropdownIdx].links;
        let link = getLinkByPath(links, path);
        let newText = prompt("Edit link text:", link.text);
        let newUrl = link.url !== undefined ? prompt("Edit link URL:", link.url) : undefined;
        if (newText) link.text = newText;
        if (newUrl !== undefined) link.url = newUrl;
        saveConfig();
    }
    function editDropdown(dropdownIdx, path) {
        let links = dropdownConfig[dropdownIdx].links;
        let link = getLinkByPath(links, path);
        let newText = prompt("Edit splitter title:", link.text);
        if (newText) link.text = newText;
        saveConfig();
    }
    function editDropdownTitle(idx) {
        let newTitle = prompt("Edit dropdown title:", dropdownConfig[idx].title);
        if (newTitle) dropdownConfig[idx].title = newTitle;
        saveConfig();
    }
    function moveLink(dropdownIdx, path, direction) {
        let links = dropdownConfig[dropdownIdx].links;
        // Traverse to the parent array containing the intended item
        let parent = links;
        if (path.length > 1) {
            for (let i=0; i<path.length-1; ++i) {
                parent = parent[path[i]].children;
            }
        }
        let idx = path[path.length - 1];
        if ((direction === 'up' && idx === 0) || (direction === 'down' && idx === parent.length - 1)) return;
        let swapWith = direction === 'up' ? idx - 1 : idx + 1;
        [parent[idx], parent[swapWith]] = [parent[swapWith], parent[idx]];
        saveConfig();
    }
    function moveDropdown(idx, direction) {
        if ((direction === 'up' && idx === 0) || (direction === 'down' && idx === dropdownConfig.length - 1)) return;
        let swapWith = direction === 'up' ? idx - 1 : idx + 1;
        [dropdownConfig[idx], dropdownConfig[swapWith]] = [dropdownConfig[swapWith], dropdownConfig[idx]];
        saveConfig();
    }
    function saveConfig() {
        fetch('dropdown_config.php', {
            method: 'POST',
            body: JSON.stringify(dropdownConfig)
        })
        .then(r => r.json())
        .then(res => {
            if (res.success) loadConfig();
            else alert('Failed to save: ' + (res.error || 'Unknown error'));
        });
    }
    function showLogin() {
        document.body.classList.remove('admin-panel-mode');
        document.body.innerHTML = `
            <main style="max-width:400px;margin:4rem auto;text-align:center;">
                <h2>Admin Login</h2>
                <input type="password" id="adminPass" placeholder="Password"><br>
                <button onclick="doLogin()">Login</button>
            </main>
        `;
    }
    function doLogin() {
        fetch('dropdown_config.php', {
            method: 'POST',
            headers: {'Content-Type':'application/x-www-form-urlencoded'},
            body: 'login=1&password=' + encodeURIComponent(document.getElementById('adminPass').value)
        })
        .then(r=>r.json())
        .then(res=>{
            if(res.success) location.reload();
            else alert('Wrong password');
        });
    }
    function showAdminPanel() {
        document.body.classList.add('admin-panel-mode');  // PATCH: fix scroll for admin
        document.body.innerHTML = `
            <header><h1>Admin Configurator</h1><div id="live-users">Loading...</div></header>
            <main style="max-width:700px;margin:2rem auto;">
                <div id="admin-menu"></div>
                <button onclick="addDropdown()">Add Dropdown</button>
                <button onclick="logoutAdmin()">Logout</button>
            </main>
        `;
        renderAdminMenu();
    }
    
    function addDropdown() {
        let title = prompt("Dropdown title?");
        if (!title) return;
        dropdownConfig.push({title, links: []});
        saveConfig();
    }
    function logoutAdmin() {
        document.body.classList.remove('admin-panel-mode');
        fetch('dropdown_config.php', {
            method: 'POST',
            headers: {'Content-Type':'application/x-www-form-urlencoded'},
            body: 'logout=1'
        }).then(() => {
            window.location.hash = '';
            location.reload();
        });
    }
    if (window.location.hash === "#admin") {
        fetch('dropdown_config.php')
            .then(r=>r.json())
            .then(res => {
                if (res.isAdmin) {
                    dropdownConfig = res.config;
                    isAdmin = true;
                    showAdminPanel();
                } else {
                    showLogin();
                }
            })
            .catch(showLogin);
    } else {
        loadConfig();
    }

    function loadNwBuddyBuildDetails(url) {
    const buildInfoDiv = document.getElementById('build-info');
    buildInfoDiv.innerHTML = '<div>Loading build details...</div>';
    fetch(`/api/nw-buddy-scraper.php?url=` + encodeURIComponent(url))
        .then(response => response.json())
        .then(res => {
            if (!res.success) {
                buildInfoDiv.innerHTML = '<div>Error loading build: ' + (res.error || 'Unknown error') + '</div>';
                return;
            }
            const d = res.data;

            // Render according to buildspage.jpg scheme
            buildInfoDiv.innerHTML = `
<div class="build-schema">
  <div class="row">
    <div>Primary weapon: ${d.primary_weapon}</div>
    <div>Secondary weapon: ${d.secondary_weapon}</div>
    <div>Skill Trees: ${d.skill_trees ? d.skill_trees.join(', ') : ''}</div>
  </div>
  <div class="gear-row">
    <div>Helmet: ${d.helmet}</div>
    <div>Chest: ${d.chest}</div>
    <div>Gloves: ${d.gloves}</div>
    <div>Pants: ${d.pants}</div>
    <div>Boots: ${d.boots}</div>
    <div>Amulet: ${d.amulet}</div>
    <div>Ring: ${d.ring}</div>
    <div>Earring: ${d.earring}</div>
  </div>
  <div class="attribute-trees">ATTRIBUTE TREES: ${d.attribute_trees ? d.attribute_trees.join(', ') : ''}</div>
  <div class="perks">Perks: ${d.perks ? d.perks.join(', ') : ''}</div>
</div>`;
        });
}

   
    document.addEventListener("DOMContentLoaded", renderOverlaySocial);
    
    </script>
</body>
</html>
