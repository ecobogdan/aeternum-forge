<?php
    require('requires/meta_tags.php');
    ?>

  <!-- Structured Data -->
  <script type="application/ld+json">
  {
    "@context": "https://schema.org",
    "@type": "Article",
    "headline": "About",
    "description": "About LLangi",
    "author": {
      "@type": "Person",
      "name": "NW Builds"
    },
    "dateModified": "2025-08-17",
    "datePublished": "2025-08-17",
    "mainEntityOfPage": {
      "@type": "WebPage",
      "@id": "https://www.nw-builds.com/about"
    },
    "publisher": {
      "@type": "Organization",
      "name": "NW Builds",
      "logo": {
        "@type": "ImageObject",
        "url": "https://www.nw-builds.com/logo.png"
      }
    }
  }
  </script>

   <style>
    :root{
      --bg:#0b0d12;
      --fg:#e7e9ee;
      --muted:#aab1bf;
      --accent:#5de1a7;
      --accent-2:#6cb6ff;
      --card:#10141c;
      --border:#1c2230;
      --warning:#ffd166;
            --accent-gold: #dab562;
            --accent-gold-dark: #a3822d;
            --bg-section: #f8f3e3;
            --shadow: 0 8px 44px #dab56233;
            --main-max-width: 700px;      
    }
    html,body{
        margin:0;
        padding:0;
        background: #080909 url('https://images.unsplash.com/photo-1506744038136-46273834b3fb?auto=format&fit=crop&w=1600&q=80') center center/cover no-repeat fixed;        color:var(--fg);
        font:16px/1.6 system-ui,-apple-system,Segoe UI,Roboto,Inter,Helvetica,Arial,sans-serif
    }
    a{
        color:var(--accent-2);
        text-decoration:none
    }
    a:hover{
        text-decoration:underline
    }
    .container{
        background: linear-gradient(90deg, #13120a 0%, #31372a 100%);
        max-width:80%;
        margin:auto;
        padding:32px 20px
    }
    header h1{
        font-size:clamp(28px,4vw,42px);
        line-height:1.2;
        margin:0 0 8px 0
    }
    header p{
        color:var(--muted);
        margin:0 0 24px 0}
    .meta{
        display:flex;
        gap:16px;
        flex-wrap:wrap;
        color:var(--muted);
        font-size:14px;
        margin-bottom:24px
    }
    .card{
        background:var(--card)
        ;border:1px solid var(--border);
        border-radius:16px;
        padding:20px
    }
    .toc{
        position:relative
    }
    .toc h2{margin-top:0}
    .toc ol{
        margin:0;
    padding-left:20px;
    display:grid;
    gap:6px
    }
    .callout{
        border-left:4px solid var(--accent);
        background:linear-gradient(90deg,rgba(93,225,167,0.1),transparent);
        padding:12px 14px;
        border-radius:10px;
        margin:16px 0
    }
    .callout.warn{
        border-left-color:var(--warning);
        background:linear-gradient(90deg,rgba(255,209,102,0.12),transparent)
    }
    h2{
        font-size:clamp(22px,3vw,30px);
        margin:28px 0 12px
    }
    h3{
        font-size:20px;
        margin:22px 0 8px
    }
    ul{padding-left:22px}
    .grid{
        display:grid;
        gap:16px
    }
    @media(min-width:900px){
        .grid.two{grid-template-columns:2fr 1fr} 
    }
    table{
        width:100%;
        border-collapse:separate;
        border-spacing:0;
        background:var(--card);
        border:1px solid var(--border);
        border-radius:14px;
        overflow:hidden;
        margin:12px 0
    }
    th,td{
        padding:12px 14px;
        border-bottom:1px solid var(--border);
        vertical-align:top
    }
    th{
        background:#0e141f;
    text-align:left;
    font-weight:600
    }
    tr:last-child td{border-bottom:none}
    code,kbd{
        background:#0d1117;
        border:1px solid #1f2836;
        border-radius:6px;
        padding:1px 6px;
        font-family:ui-monospace,SFMono-Regular,Menlo,Monaco,Consolas,"Liberation Mono","Courier New",monospace;
        font-size:0.95em
    }
    .sticky-sidebar{
        position:sticky;
        top:16px;
        height:max-content
    }
    .label{
        display:inline-block;
        font-size:12px;
        color:#0b0d12;
        background:var(--accent);
        padding:2px 8px;
        border-radius:999px;
        margin-right:8px
    }
    .footer-cta{
        display:flex;
        flex-wrap:wrap;
        gap:12px;
        margin-top:28px
    }
    .btn{
        display:inline-block;
        padding:10px 14px;
        border-radius:10px;
        border:1px solid var(--border);
        background:#0f1622;
        color:var(--fg);
        text-decoration:none
    }
    .btn.primary{
        background:linear-gradient(180deg,var(--accent),#49c48e);
        color:#0b0d12;
        border:none;
        font-weight:600
    }
    .muted{color:var(--muted)}
    .hr{
        height:1px;
        background:var(--border);
        margin:24px 0
    }
    .titul{font-size:clamp(28px,4vw,42px);line-height:1.2;margin:0 0 8px 0}
    /***************************************/
     header {
            background: linear-gradient(90deg, #13120a 0%, #31372a 100%);
            padding: 0.1rem 0 0.75rem 0;
            box-shadow: 0 2px 18px #060605c9;
            border-radius: 0 0 var(--round) var(--round);
            color: var(--accent-gold);
            width: 100vw;
            text-align: center;
            letter-spacing: 1.2px;
            font-family: inherit;
            position: relative;
            z-index: 80;
        }
        .nav-bar {
            display: grid;
            grid-template-columns: 1fr auto 1fr;
            align-items: center;
            width: 100%;
            max-width: 1400px;
            margin: 0 auto;
            gap: 0.5rem;
        }
        .nav-col-left, .nav-col-right {
            display: flex;
            align-items: center;
            gap: 1.1rem;
        }
        .nav-col-left {
            justify-content: flex-start;
        }
        .nav-col-right {
            justify-content: flex-end;
        }
        .logo-area {
            display: flex;
            flex-direction: column;
            align-items: center;
            gap: 0.3rem;
            grid-column: 2;
        }
        .logo-img {
            width: 58px;
            height: 58px;
            border-radius: 50%;
            border: 2.3px solid var(--accent-gold);
            box-shadow: 0 0 16px #b49a4a99;
            background: #0002;
            display: block;
            margin: 0 auto;
        }
        .site-title {
            font-size: 1.6rem;
            margin: 0.2em 0 0.13em 0;
            letter-spacing: 2px;
            font-weight: 700;
            text-shadow: 0 2px 16px #b49a4a80, 0 0 4px #0006;
            color: var(--accent-gold);
            text-align: center;
        }
        .nav-link {
            color: var(--accent-gold);
            text-decoration: none;
            font-weight: 500;
            font-size: 1.02rem;
            letter-spacing: 0.05em;
            position: relative;
            padding: 0.24em 0.44em;
            border-radius: 8px;
            font-family: inherit;
            transition: background 0.19s, color 0.19s, box-shadow 0.19s;
        }
        .nav-link:hover {
            background: #272106d9;
            color: #fffbe6;
            box-shadow: 0 0 8px #dab56255;
        }
        .social-link {
            display: flex;
            align-items: center;
            color: var(--accent-gold);
            background: #13120c;
            border-radius: 8px;
            padding: 0.22em 0.7em;
            gap: 0.28em;
            font-size: 1rem;
            text-decoration: none;
            box-shadow: 0 1px 8px #dab56234;
            border: 1.4px solid #493d1550;
            transition: background 0.19s, color 0.19s, box-shadow 0.18s;
        }
        .social-link:hover {
            background: #2d2716;
            color: #fff8d5;
            box-shadow: 0 0 8px #dab56299;
            border-color: #dab56299;
        }
        .hamburger {
            display: none;
            flex-direction: column;
            justify-content: center;
            align-items: center;
            width: 48px;
            height: 48px;
            border: none;
            background: transparent;
            cursor: pointer;
            grid-column: 3 / span 1;
            z-index: 110;
        }
        .hamburger-bar {
            width: 32px;
            height: 4px;
            background: var(--accent-gold);
            margin: 4px 0;
            border-radius: 4px;
            box-shadow: 0 1px 2px #fbebc6;
            transition: all 0.31s cubic-bezier(.55,0,.23,1.2);
        }
        .hamburger.active .hb-1 { transform: translateY(8px) rotate(45deg); background: #fff; }
        .hamburger.active .hb-2 { opacity: 0; }
        .hamburger.active .hb-3 { transform: translateY(-8px) rotate(-45deg); background: #fff; }
        .nav-overlay {
            display: none;
            position: fixed;
            z-index: 100;
            inset: 0;
            width: 100vw;
            height: 100vh;
            background: #19120ad8;
            backdrop-filter: blur(4px) brightness(0.8);
            flex-direction: column;
            align-items: center;
            justify-content: center;
            gap: 2.2rem;
            opacity: 0;
            pointer-events: none;
            transition: opacity 0.23s;
        }
        .nav-overlay.open { display: flex; opacity: 1; pointer-events: unset;}
        .nav-overlay .nav-overlay-group {
            display: flex;
            flex-direction: column;
            align-items: center;
            gap: 2rem;
        }
        .nav-overlay .nav-link,
        .nav-overlay .social-link {
            font-size: 1.25rem;
            background: none;
            box-shadow: none;
            border: none;
            color: var(--accent-gold);
        }
        @media (max-width: 1450px) {
             .dropdown-bar {
                max-width: 99vw;
            }
        }
        @media (max-width: 1100px) {
            
            .dropdown-bar { gap: 0.7rem; }
        }
        @media (max-width: 900px) {
            .dropdown-bar { flex-wrap: wrap; justify-content: flex-start; }
            .logo-img { width: 38px; height: 38px;}
            .site-title { font-size: 1.11rem;}
            .nav-bar { gap: 0.1rem;}
        }
        @media (max-width: 850px) {
            .nav-bar { grid-template-columns: 1fr auto 1fr; padding: 0 0.2em; }
            .nav-col-left, .nav-col-right { display: none; }
            .hamburger { display: flex; }
            .logo-area { grid-column: 2; }
            .container {max-width:100%;}
             html,body{
            font:12px/1.6 system-ui,-apple-system,Segoe UI,Roboto,Inter,Helvetica,Arial,sans-serif
            }
        }
        @media (max-width: 700px) {
            .nav-bar { grid-template-columns: 1fr auto 1fr; padding: 0 0.2em; }
            .nav-col-left, .nav-col-right { display: none; }
            .hamburger { display: flex; }
            .logo-area { grid-column: 2; }
            .container {max-width:100%;}
             html,body{
            font:12px/1.6 system-ui,-apple-system,Segoe UI,Roboto,Inter,Helvetica,Arial,sans-serif
    }
        }
        @media (max-width: 530px) {
            .logo-img { width: 27px; height: 27px;}
            .site-title { font-size: 0.98rem;}
            
        }
        .nav-dropdown {
            position: relative;
            display: flex;          /* so .nav-link fills the div */
            align-items: center;
        }
        
        .nav-dropdown > .nav-link:after {
            content: ' ▼';
            font-size: 0.73em;
            color: var(--accent-gold-dark);
            padding-left: 0.18em;
            transition: color 0.18s;
        }
        .nav-dropdown.open > .nav-link:after {
            color: #fffbe6;
        }
        .dropdown-menu {
            display: none;
            position: absolute;
            left: 0; top: 120%;
            min-width: 180px;
            background: #181309;
            box-shadow: 0 6px 22px #dab56233, 0 2px 8px #dab56228;
            border: 1.3px solid #dab56255;
            border-radius: 12px;
            z-index: 1001;
            padding: 0.28em 0;
            transition: opacity .18s, visibility .18s;
            opacity: 0;
            visibility: hidden;
        }
        .nav-dropdown.open .dropdown-menu {
            display: block;
            opacity: 1;
            visibility: visible;
        }
        .dropdown-menu a {
            display: block;
            color: var(--accent-gold);
            background: none;
            padding: 0.58em 1.2em;
            font-size: 1.01rem;
            border-radius: 7px;
            text-decoration: none;
            transition: background 0.14s, color 0.17s;
            text-align: left;
            letter-spacing: 0.03em;
        }
        .dropdown-menu a:hover, .dropdown-menu a:focus {
            background: #272106d9;
            color: #fffbe6;
        }
        @media (max-width: 850px) {
          .dropdown-menu {
            position: static;
            min-width: 0;
            box-shadow: none;
            padding: 0.18em 0 0.13em 0;
            background: none;
            border: none;
            opacity: 1;
            visibility: visible;
            display: block;
          }
          .nav-dropdown.open .dropdown-menu, .nav-dropdown:hover .dropdown-menu {
            display: block;
          }
          .nav-dropdown > .nav-link:after {
              /* bigger for touch */
              font-size: 1.11em;
          }
        }
        @media (max-width: 700px) {
          .dropdown-menu {
            position: static;
            min-width: 0;
            box-shadow: none;
            padding: 0.18em 0 0.13em 0;
            background: none;
            border: none;
            opacity: 1;
            visibility: visible;
            display: block;
          }
          .nav-dropdown.open .dropdown-menu, .nav-dropdown:hover .dropdown-menu {
            display: block;
          }
          .nav-dropdown > .nav-link:after {
              /* bigger for touch */
              font-size: 1.11em;
          }
          iframe {
              width: 280px;
              height: 155px;
          }
        }
  </style>
</head>
<body>
    <?php
    require('requires/header.php');
    ?>
  <div class="container">
    <div>
      <span class="label">About</span>
      <h1 class="titul">About LLangi</h1>
      <p class="muted">“LLangi” is a leading New World: Aeternum content creator, Twitch Partner, and the founder of nw-builds — a comprehensive resource for community builds, guides, and tools tailored to both PvE and PvP players. His work is built on long-term gaming experience, a commitment to accuracy, and a deep engagement with community feedback.</p>
      <div class="meta">
        <div>Last updated: <time datetime="2025-09-15">September 15, 2025</time></div>
        <div>Reading time: ~5 min</div>
      </div>
    </div>

    <div class="grid two">
      <article>
        <section id="origins">
            
          <h2>Origins & Experience</h2>
          <p>From early days immersed in MMORPGs, LLangi has developed a profound understanding of game mechanics, balance, and what makes content both “meta”-viable and fun. Prior to New World, he spent many years in other MMOs, refining his skills, strategy insight, and player perspective.</p>
          <p>With New World: Aeternum, he has found a platform where both the complexity of build design and the dynamic gameplay between PvE & PvP allow his strengths to shine — testing, optimizing, and sharing with a growing audience.</p>
        </section>

        <section id="philosophy">
          <h2>Mission & Philosophy</h2>
          <p>LLangi’s mission is to empower players. Whether you're just reaching level 65, diving into end-game content, or exploring alternative builds for fun, the aim is to provide:</p>
          <ul>
            <li><strong>Accuracy & Testing:</strong> Builds and guides are not theoretical alone — they are live-tested, subject to patch changes, and maintained over time.</li>
            <li><strong>Transparency:</strong> Gear choices, trade-offs, and limitations are clearly explained.</li>
            <li><strong>Accessibility:</strong> Resources are organized so that both newcomers and veteran players can find value—whether in starter guides, result-driven PvP setups, or raid-ready PvE meta builds.</li>
            <li><strong>Community Collaboration:</strong> Viewers and followers are not passive consumers but active participants. Feedback, questions, and suggestions often influence what builds or tools get priority.</li>
          </ul>
        </section>

        <section id="nw-builds">
          <h2>What NW Builds Offers</h2>
          <p>Through his platform NW Builds (nw-builds.com), LLangi delivers:</p>
          <ul>
            <li><strong>Meta & Off-Meta Builds:</strong> Gear loadouts for different roles, whether damage, tanking, or support; optimized for both competitive and casual play.</li>
            <li><strong>Detailed Guides & Tools:</strong> In-depth PvE and PvP guides, leveling tips, gold-making strategies, refining tools and calculators, and help with understanding game mechanics.</li>
            <li><strong>Regular Updates:</strong> As the New World meta shifts with patches, LLangi updates builds and guides to reflect balance changes, gear adjustments, and community insights.</li>
            <li><strong>Multimedia Content:</strong> Streaming live on Twitch, posting recordings & highlights, producing guide videos and Q&A sessions. Content is often intertwined — e.g., builds developed on stream are then documented on the site.</li>
            <li>
          </ul>
        </section>

        <section id="audience">
          <h2>Audience & Reach</h2>
           <p>LLangi maintains an international audience by streaming primarily in <strong>English</strong>, which allows the content to reach a broad player base across regions. The Twitch channel serves as both an entertainment venue and a testing ground — real-time feedback and live experimentation are used to refine what shows up on NW Builds.</p>
           <p>His community includes a loyal base of viewers who:</p>
          <ul>
            <li>Participate in live chats, giving suggestions and asking for builds.</li>
            <li>Use the tools and guides to improve their play.</li>
            <li>Engage with updates, patches, and meta-shifts through NW Builds and social channels.</li>
          </ul>
        </section>

        <section id="difference">
          <h2>What Sets LLangi Apart</h2>
          <ul>
            <li><strong>Dual Role as Creator & Tester:</strong> Not only does LLangi theorize builds, he actively tests them — in live gameplay, PvE content, and PvP — ensuring practical utility.</li>
            <li><strong>Build Variety:</strong> Beyond simply offering “best DPS,” his guides include alternative or off-meta options, hybrid choices, or builds suited for different playstyles or gear budgets.</li>
            <li><strong>Resource Tools:</strong> Refining calculators, price-watching, gear-slot comparisons, and mechanics/role breakdowns are part of the offering — tools many players struggle to piece together themselves.</li>
            <li><strong>Timely Adaptation:</strong> As patches alter balance, new gear is introduced, or meta shifts occur, LLangi’s content tracks those changes.</li>
          </ul>
        </section>

        <div class="hr"></div>

        <section id="final-thoughts" style="margin-bottom: 50px">
          <h2>Invitation to Join</h2>
          <p>NW Builds is more than just a site. It’s a hub for players who want to up their game, stay ahead of patch changes, and explore New World with clarity and strategy.</p>
          <p>Whether you’re here for your first PvE expedition, your first War, or your tenth alternative build, LLangi and the NW Builds community are here to help you master Aeternum.</p>
         
        </section>
      </article>

      <aside class="sticky-sidebar">
        <nav class="card toc" aria-label="On this page">
          <h2>Table of Contents</h2>
          <ol>
            <li><a href="#origins">Origins & Experience</a></li>
            <li><a href="#philosophy">Mission & Philosophy</a></li>
            <li><a href="#nw-builds">What NW Builds Offers</a></li>
            <li><a href="#audience">Audience & Reach</a></li>
            <li><a href="#difference">What Sets LLangi Apart</a></li>
          </ol>
        </nav>

        <div class="card" style="margin-top:16px">
          <h3>Stay Connected</h3>
          <ul>
            <li><a href="https://www.twitch.tv/llangi">Twitch</a></li>
            <li><a href="https://www.youtube.com/@LLangiTTV">Youtube</a></li>
            <li><a href="https://discord.gg/mysDhRuKVY">Discord</a></li>

          </ul>
        </div>

        
      </aside>
    </div>
  </div>
  <script>
      <?php
    require('requires/header_script.php');
    ?>
  </script>
</body>
</html>
