<?php
header('Content-Type: application/json');

// Get URL param
if (!isset($_GET['url'])) {
    echo json_encode(['error' => 'Missing URL']);
    exit;
}
$url = $_GET['url'];
if (strpos($url, 'nw-buddy.de/gearsets/') === false && strpos($url, 'nw-buddy.de/gearsets/share/') === false) {
    echo json_encode(['error' => 'URL must be a nw-buddy gearset/ link']);
    exit;
}

// Fetch HTML via cURL proxy
$ch = curl_init();
curl_setopt($ch, CURLOPT_URL, $url);
curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
curl_setopt($ch, CURLOPT_FOLLOWLOCATION, true);
curl_setopt($ch, CURLOPT_USERAGENT, $_SERVER['HTTP_USER_AGENT'] ?? 'Mozilla/5.0');
$html = curl_exec($ch);
curl_close($ch);

if (!$html) {
    echo json_encode(['error' => 'Failed to fetch']);
    exit;
}

// Prepare the DOM
libxml_use_internal_errors(true);
$dom = new DOMDocument();
$dom->loadHTML($html);
$xpath = new DOMXPath($dom);

// Helper function: Find gear item by type text (e.g. 'Helmet', 'Ring')
function findGearByType($xpath, $typeText) {
    // Icon box node containing the type text
    $query = "//span[contains(text(), '$typeText')]";
    $nodes = $xpath->query($query);
    if ($nodes->length === 0) return null;
    $spanNode = $nodes->item(0);

    // Climb to parent, then search details
    $itemCard = $spanNode;
    // Try climbing out to nearest nwb-item-card parent
    for ($i=0; $i<10 && $itemCard; $i++) {
        if ($itemCard->nodeName === 'nwb-item-card') break;
        $itemCard = $itemCard->parentNode;
    }
    if (!$itemCard || $itemCard->nodeName !== 'nwb-item-card') return null;

    // Name: find first span inside nwb-item-header-content
    $nameNode = $xpath->query(".//nwb-item-header-content//span", $itemCard)->item(0);
    $name = $nameNode ? trim($nameNode->textContent) : '';

    // Rarity: look for text-*-* classes
    $rarityNode = $xpath->query(".//*[contains(@class,'text-rarity-')]", $itemCard)->item(0);
    $rarity = $rarityNode ? trim($rarityNode->textContent) : '';

    // Gear Score
    $gsNode = $xpath->query(".//nwb-item-gs/span", $itemCard)->item(0);
    $gs = $gsNode ? trim($gsNode->textContent) : '';

    // Perks
    $perks = [];
    foreach ($xpath->query(".//nwb-item-perk", $itemCard) as $pk) {
        $perkName = $xpath->query(".//div/b", $pk)->item(0);
        $perkDesc = $xpath->query(".//div/span", $pk)->item(0);
        $perks[] = [
            'name' => $perkName ? trim($perkName->textContent) : '',
            'desc' => $perkDesc ? trim($perkDesc->textContent) : '',
        ];
    }
    return [
        'name' => $name,
        'rarity' => $rarity,
        'gear_score' => $gs,
        'perks' => $perks
    ];
}

// Build main info structure
$data = [
    'helmet'    => findGearByType($xpath, 'Helmet'),
    'chest'     => findGearByType($xpath, 'Chest'),
    'gloves'    => findGearByType($xpath, 'Gloves'),
    'pants'     => findGearByType($xpath, 'Pants'),
    'boots'     => findGearByType($xpath, 'Boots'),
    'amulet'    => findGearByType($xpath, 'Amulet'),
    'ring'      => findGearByType($xpath, 'Ring'),
    'earring'   => findGearByType($xpath, 'Earring'),
    // For weapons: look for slot text
    'primary_weapon'   => findGearByType($xpath, 'Primary'),   // e.g. 'Primary weapon' text
    'secondary_weapon' => findGearByType($xpath, 'Secondary'),
];

// Simple skill tree and attributes extraction (if present)
$skillTrees = [];
$attributeTrees = [];
foreach ($xpath->query("//div[contains(text(),'Skill tree') or contains(text(),'Skill trees')]") as $node) {
    $skillTrees[] = trim($node->textContent);
}
foreach ($xpath->query("//div[contains(text(),'ATTRIBUTE TREE') or contains(text(),'ATTRIBUTE TREES')]") as $node) {
    $attributeTrees[] = trim($node->textContent);
}
$data['skill_trees'] = $skillTrees;
$data['attribute_trees'] = $attributeTrees;

echo json_encode(['success' => true, 'data' => $data]);
